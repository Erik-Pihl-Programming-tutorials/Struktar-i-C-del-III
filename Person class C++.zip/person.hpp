/********************************************************************************
* person.hpp: Inneh�ller funktionalitet f�r lagring samt utskrift av persondata
*             via klassen person.
********************************************************************************/
#ifndef PERSON_HPP_
#define PERSON_HPP_

/* Inkluderingsdirektiv: */
#include <iostream>
#include <string>

/********************************************************************************
* gender: Enumeration f�r val av k�n.
********************************************************************************/
enum class gender
{
   male,   /* Man. */
   female, /* Kvinna. */
   other,  /* �vrigt. */
   none    /* Ospecifierat. */
};

/********************************************************************************
* person: Klass f�r lagring och utskrift av persondata.
********************************************************************************/
class person
{
private:
   std::string name_;                        /* Personens namn. */
   unsigned int age_ = 0;                    /* Personens �lder. */
   std::string address_;                     /* Personens hemadress. */
   std::string occupation_;                  /* Personens yrke. */
   enum class gender gender_ = gender::none; /* Personens k�n. */

public:

   /********************************************************************************
   * person: Konstruktor, initierar nytt person-objekt med angiven persondata.
   *
   *         - name      : Pekare till textstycke inneh�llande personens namn.
   *         - age       : Personens �lder.
   *         - address   : Personens adress.
   *         - occupation: Personens yrke.
   *         - gender    : Personens k�n.
   ********************************************************************************/
   person(const std::string& name,
          const unsigned int age,
          const std::string& address,
          const std::string& occupation,
          const enum gender gender)
   {
      this->name_ = name;
      this->age_ = age;
      this->address_ = address,
      this->occupation_ = occupation,
      this->gender_ = gender;
      return;
   }

   /********************************************************************************
   * ~person: Destruktor, t�mmer objekt innan det raderas (beh�vs ej h�r, d�
   *          ingen dynamisk minnesallokering genomf�rs).
   ********************************************************************************/
   ~person(void)
   {
      this->clear();
      return;
   }

   /********************************************************************************
   * name: Returnerar personens namn.
   ********************************************************************************/
   const std::string& name(void) const
   {
      return this->name_;
   }

   /********************************************************************************
   * age: Returnerar personens �lder.
   ********************************************************************************/
   unsigned int age(void) const
   {
      return this->age_;
   }

   /********************************************************************************
   * address: Returnerar personens hemadress.
   ********************************************************************************/
   const std::string& address(void) const
   {
      return this->address_;
   }

   /********************************************************************************
   * occupation: Returnerar personens yrke.
   ********************************************************************************/
   const std::string& occupation(void) const
   {
      return this->occupation_;
   }

   /********************************************************************************
   * gender: Returnerar personens k�n.
   ********************************************************************************/
   enum gender gender(void) const
   {
      return this->gender_;
   }

   /********************************************************************************
   * gender_str: Returnerar personens k�n i form av en str�ng.
   ********************************************************************************/
   const char* gender_str(void) const
   {
      if (this->gender_ == gender::male) return "Male";
      else if (this->gender_ == gender::female) return "Female";
      else if (this->gender_ == gender::other) return "Other";
      else return "Unspecified";
   }

   /********************************************************************************
   * clear: Nollst�ller persondata f�r angivet objekt.
   ********************************************************************************/
   void clear(void)
   {
      this->name_.clear();
      this->age_ = 0;
      this->address_.clear();
      this->occupation_.clear();
      this->gender_ = gender::none;
      return;
   }

   /********************************************************************************
   * print: Skriver ut persondata till angiven utstr�m, d�r standardutenhet
   *        std::cout anv�nds som default f�r utskrift i terminalen.
   *
   *        - ostream: Referens till angiven utstr�m (default = std::cout).
   ********************************************************************************/
   void print(std::ostream& ostream = std::cout) const
   {   
      ostream << "--------------------------------------------------------------------------------\n";
      ostream << "Name: " << this->name_ << "\n";
      ostream << "Age: " << this->age_ << "\n";
      ostream << "Address: " << this->address_ << "\n";
      ostream << "Occupation: " << this->occupation_ << "\n";
      ostream << "Gender: " << this->gender_str() << "\n";
      ostream << "--------------------------------------------------------------------------------\n\n";
      return;
   }
};

#endif /* PERSON_HPP_ */